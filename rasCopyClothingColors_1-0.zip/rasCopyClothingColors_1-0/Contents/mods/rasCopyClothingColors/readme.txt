


-------------------- FOR PLAYERS/GENERAL AUDIENCE ---------------------


This mod makes it possible to copy the color of a clothing item to different clothing item during character customisation. For more info, see the mod's workshop page on steam.


------------------------- UPDATE NOTES ---------------------------- 


- 1.0: release version


------------------------- TECHNICAL/FOR MODDERS/MISC -------------------------


No vanilla functions are overwritten but constructions like

local vanilla_Function = vanillaFunction
function vanillaFunction()

  vanilla_Function() -- execute vanilla code

  --[[ new code ]]--
end

are used to modify vanilla functions. The mod only modifies some functions from vanilla client/ISUI/ISColorPickerHSB.lua.

         
---------------------- LANGUAGE AND TRANSLATION ---------------------------------


Currently only available in English.


----------------------- DISCLAIMER -------------------------------


I consider all my mods to be open source. As long as you do not publish a plain copy of the mod to the steam workshop, feel free to use any element of it, modify to your liking and share with the community! 


-----------------------


by razab, March 26, 2025







